new Typed('.typed',{
    strings : ['FrontEnd Developer','Web Designer'],
    typeSpeed : 90,
    delaySpeed : 90,
    loop : true
  });


  const header = document.querySelector(".page-header");
const toggleClass = "sticky";

window.addEventListener("scroll", () => {
  const currentScroll = window.pageYOffset;
  if (currentScroll > 310) {
    header.classList.add(toggleClass);
  
  } else {
    header.classList.remove(toggleClass);
  }
});

$('.line').click( function(){
   $('.list').slideToggle(700);
   $('.list').css('display','flex');
})

